// Grupo composto por apenas 1 integrante:
// RM85181 - Luan Henrique Silva Neves



// A - Criando o banco de dados chamado SDG
use SDG

// B - Criando a collection chamada SDG_2 no banco de dados
db.createCollection("SDG_2")

// C - Inserindo os documentos na collection
db.SDG_2.insert({
  GOAL: 2,
  TARGET: "2.1",
  INDICATOR: "2.1.2",
  SERIES_CODE: "AG_PRD_FIESMS",
  SERIES_DESCRIPRITION: "Prevalence of moderate or severe food insecurity in the adult population (%)",
  GEO_AREA_NAME: "Austria",
  TIME_PERIOD: 2015,
  VALUES: 3.8
})

db.SDG_2.insert({
  GOAL: 2,
  TARGET: "2.c",
  INDICATOR: "2.c.1",
  SERIES_DESCRIPRITION: "Indicator of Food Price Anomalies (IFPA), by type of product",
  GEO_AREA_NAME: "Mozambique",
  TIME_PERIOD: 2016,
  VALUES: 3.4
})

db.SDG_2.insert({
  GOAL: 2,
  TARGET: "2.a",
  INDICATOR: "2.a.1",
  SERIES_CODE: "AG_PRD_AGVAS",
  SERIES_DESCRIPRITION: "Agriculture value added share of GDP (%)",
  GEO_AREA_NAME: "Marshall Islands",
  TIME_PERIOD: 2019,
  VALUES: 15.80
})


// D - Fazendo uma pesquisa para retornar todos os documentos que tem o valor (Values) menor que 10 e que o período (time_period) seja igual a 2016
db.SDG_2.find({$and:[{VALUES : {$lt: 10}}, {TIME_PERIOD: 2016}]})


// E - Atualizando o valor (VALUES) para 16.85 do documento cujo indicador (INDICATOR) é igual a 2.a.1
db.SDG_2.update({'INDICATOR' : '2.a.1'},{$set:{VALUES: 16.85}})


// F - Remova o documento cujo alvo (TARGET) e igual a 2.c
db.SDG_2.remove({'TARGET': '2.c'})
